
Menu = function(){
  print("1. Crear dos Matrices de 100x100 de distribuci�n normal")
  print("2. multiplicar las matrices del punto 1")
  print("3. Mostrar el tiempo de ejecuci�n del punto 2")
  
  val = as.integer(readline("Ingrese una opci�n: "))
  if (val == 1){
    Matriz1 = matrix(rnorm(100),ncol = 100, nrow = 100)
    Matriz1
    
    Matriz2 = matrix(rnorm(100),ncol = 100, nrow = 100)
    Matriz2}
  else if (val == 2){
    Matriz1 = matrix(rnorm(100),ncol = 100, nrow = 100)
    Matriz2 = matrix(rnorm(100),ncol = 100, nrow = 100)
    Mulmatrix =  Matriz1%*%Matriz2
    Mulmatrix}
  else if (val == 3){
    Matriz1 = matrix(rnorm(100),ncol = 100, nrow = 100)
    Matriz2 = matrix(rnorm(100),ncol = 100, nrow = 100)
    print("El tiempo que tard� en ejecutar el punto 2 fue de: ")
    proc.time()
    ptm <- proc.time()
    Matriz1%*%Matriz2
    proc.time() - ptm
    }
  else {
    print("No ejecutar� nada")
  }
}
  



